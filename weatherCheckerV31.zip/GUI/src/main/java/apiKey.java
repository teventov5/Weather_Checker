public class apiKey {
    public static String getApiKey()
    {
        return "rkRijfOSYOrKyHNsAmAZsNL1wD9PIe92";
    }
}
