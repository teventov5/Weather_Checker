public class Main {
    public static void main(String[] args) {
       try {
           new tweakPLAF();
           new WelcomeWindow();

       }
       catch(Exception e){System.out.println(e);}



    }
}
