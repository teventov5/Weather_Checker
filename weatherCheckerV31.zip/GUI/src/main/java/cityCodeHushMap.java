import java.util.HashMap;

public class cityCodeHushMap {
    public static HashMap<String, String> cityCodes= new HashMap<String, String>();
    public static HashMap<String, forcastResult> forecasts = new HashMap<String, forcastResult>();
    public static HashMap<String, hangoutsResult[]> hangouts = new HashMap<String, hangoutsResult[]>();


    public cityCodeHushMap() {


    }




}
